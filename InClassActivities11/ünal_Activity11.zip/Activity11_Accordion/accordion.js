$(document).ready(function() {
	$("#tabs").accordion();
});
